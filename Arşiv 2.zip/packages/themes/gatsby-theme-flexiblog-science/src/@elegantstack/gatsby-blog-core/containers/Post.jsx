export { default } from '../../../containers/Post'
