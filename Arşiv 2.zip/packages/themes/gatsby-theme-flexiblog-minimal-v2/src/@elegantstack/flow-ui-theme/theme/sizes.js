import sizes from '@elegantstack/flow-ui-theme/src/theme/sizes'

export default {
  ...sizes,
  container: 960
}
