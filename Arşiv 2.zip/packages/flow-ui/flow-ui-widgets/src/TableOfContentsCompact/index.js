export { default } from './TableOfContentsCompact'
