export { default } from './HeroWide'
