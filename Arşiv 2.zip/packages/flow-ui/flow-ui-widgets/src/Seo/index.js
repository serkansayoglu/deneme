export { default } from './Seo'
