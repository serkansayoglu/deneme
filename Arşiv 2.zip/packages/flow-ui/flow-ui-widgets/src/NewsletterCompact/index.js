export { default } from './NewsletterCompact'
