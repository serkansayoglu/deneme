export { default } from './AuthorCompact'
