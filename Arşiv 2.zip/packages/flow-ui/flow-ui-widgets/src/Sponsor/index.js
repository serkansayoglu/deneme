export { default } from './Sponsor'
