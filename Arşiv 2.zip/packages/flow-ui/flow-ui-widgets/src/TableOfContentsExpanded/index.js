export { default } from './TableOfContentsExpanded'
