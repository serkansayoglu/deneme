export { default } from './HeroBoxed'
