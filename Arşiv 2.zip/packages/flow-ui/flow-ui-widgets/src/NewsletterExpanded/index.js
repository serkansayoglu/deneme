export { default } from './NewsletterExpanded'
