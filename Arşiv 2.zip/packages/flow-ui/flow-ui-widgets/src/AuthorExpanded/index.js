export { default } from './AuthorExpanded'
