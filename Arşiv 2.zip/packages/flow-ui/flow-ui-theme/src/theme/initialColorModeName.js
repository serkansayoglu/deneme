export default 'light'
