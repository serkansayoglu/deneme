import tag from './tag'
import tagWhite from './tag-white'

export default {
  tag,
  'tag-white': tagWhite
}
