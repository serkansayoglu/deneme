import common from './common'

export default {
  ...common.button,
  color: `omegaDark`,
  bg: `mute`,
  borderColor: `mute`,
  cursor: `not-allowed`
}
