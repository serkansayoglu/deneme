import simple from './simple'

export default {
  ...simple,
  borderRadius: `full`,
  bg: `omegaLighter`,
}
