export default {
  variant: 'cards.primary',
  p: 4
}
