export default {
  sm: 1,
  md: 3,
  lg: 5,
  xl: 10,
  xxl: 20
}
