import prism from '@theme-ui/prism/presets/night-owl'

export default prism
