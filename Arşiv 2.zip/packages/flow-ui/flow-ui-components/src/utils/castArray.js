export default value => (Array.isArray(value) ? value : [value])
