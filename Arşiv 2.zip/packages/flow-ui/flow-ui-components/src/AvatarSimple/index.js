export { default } from './AvatarSimple'
