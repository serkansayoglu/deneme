module.exports = [require('./ArticleTag')]
