export { default } from '../../../containers/Collection'
